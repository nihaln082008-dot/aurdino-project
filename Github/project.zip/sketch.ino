#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Servo.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Pin mapping
const int BUTTON_PIN = 2;
const int LED_PIN = 4;
const int BUZZER_PIN = 6;
const int SERVO_PIN = 9;

Servo myServo;

int mode = 0; // Cycles through 0, 1, 2
bool lastButtonState = HIGH;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  
  myServo.attach(SERVO_PIN);
  myServo.write(0);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for(;;);
  }
  
  updateScreen();
}

void loop() {
  bool buttonState = digitalRead(BUTTON_PIN);

  // Detect button press (LOW when pressed using INPUT_PULLUP)
  if (buttonState == LOW && lastButtonState == HIGH) {
    tone(BUZZER_PIN, 1500, 50); // Short beep
    digitalWrite(LED_PIN, HIGH);
    
    // Cycle mode: 0 -> 1 -> 2 -> back to 0
    mode = (mode + 1) % 3;
    
    // Move servo based on mode
    if (mode == 0) myServo.write(0);
    else if (mode == 1) myServo.write(90);
    else if (mode == 2) myServo.write(180);

    updateScreen();
    delay(100); // LED on duration
    digitalWrite(LED_PIN, LOW);
    
    delay(200); // Simple debounce delay
  }
  lastButtonState = buttonState;
}

void updateScreen() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(10, 5);
  display.print("SIMPLE SERVO PROJECT");
  
  display.drawLine(0, 20, 128, 20, SSD1306_WHITE);
  
  display.setTextSize(2);
  display.setCursor(15, 32);
  display.print("Angle: ");
  
  if (mode == 0) display.print("0");
  else if (mode == 1) display.print("90");
  else if (mode == 2) display.print("180");
  display.print("o");
  
  display.display();
}











